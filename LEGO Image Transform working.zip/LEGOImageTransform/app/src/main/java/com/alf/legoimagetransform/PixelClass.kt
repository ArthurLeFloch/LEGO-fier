package com.alf.legoimagetransform

class PixelClass(_enabled: Boolean, _color:List<Int>) {
    val r = _color[0]
    val g = _color[1]
    val b = _color[2]
    var enabled = _enabled
}