package com.alf.legoimagetransform

import android.app.Activity
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.ColorUtils.HSLToColor
import androidx.core.graphics.ColorUtils.colorToHSL
import androidx.core.graphics.blue
import androidx.core.graphics.green
import androidx.core.graphics.red
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.alf.legoimagetransform.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.lang.Math.abs
import java.lang.Math.floorDiv


private const val TAG = "MainActivityTAG"
class MainActivity : AppCompatActivity() {

    private val REQUEST_CODE = 200

    private lateinit var binding: ActivityMainBinding
    private lateinit var fileList: MutableList<FileClass>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        /*supportActionBar?.title = getString(R.string.app_name)
        supportActionBar?.subtitle = getString(R.string.open_detail)*/

        fileList = mutableListOf()
        loadFiles()

        val layoutManager: RecyclerView.LayoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager
        binding.recyclerView.adapter = FileAdapter(this, binding.recyclerView, fileList) { position: Int ->
            onClick(
                position
            )
        }

        binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Ouverture du fichier", Snackbar.LENGTH_SHORT)
                .setAction("Action", null)
                .show()
            val intent = Intent(Intent.ACTION_PICK)
            intent.type = "image/*"
            startActivityForResult(intent, REQUEST_CODE)

        }


        // Use this setting to improve performance if you know that changes
        // in content do not change the layout size of the RecyclerView
        binding.recyclerView.setHasFixedSize(true)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == Activity.RESULT_OK && requestCode == REQUEST_CODE){


            val selectedImageURI: Uri = data?.data!!
            val imageFile = File(getRealPathFromURI(selectedImageURI))

            legofy(imageFile, selectedImageURI)



            if(!File(imageFile.path).exists()){
                Log.wtf(TAG, "Fichier inexistant")
            }
            Log.d(TAG, imageFile.path)
            //openFile(imageFile.path)

        }
    }



    private fun legofy(imageFile:File, selectedImageURI: Uri, height:Int = 80){
        val lego_colors = listOf(Triple(255,255,255),
                                Triple(0,0,0),
                                Triple(212,5,38),
                                Triple(130,3,23),
                                Triple(104,230,0),
                                Triple(0,133,40),
                                Triple(0,82,24),
                                Triple(190,198,207),
                                Triple(119,124,130),
                                Triple(245,241,0),
                                Triple(95,0,158),
                                Triple(242,236,199),
                                Triple(255,114,0),
                                Triple(110,69,47),
                                Triple(179,0,158),
                                Triple(239,161,255),
                                Triple(29,35,99),
                                Triple(36,46,212),
                                Triple(0,206,255))

        var usedColor = mutableListOf<Boolean>()
        for(i in lego_colors.indices){
            usedColor.add(false)
        }

        fun dist(pixel1: Triple<Int, Int, Int>, pixel2: Triple<Int, Int, Int>) : Int{
            return abs(pixel1.first - pixel2.first) + abs(pixel1.second - pixel2.second) + abs(pixel1.third - pixel2.third)
        }

        fun tripleToColor(triple: Triple<Int, Int, Int>): Int{
            return Color.rgb(triple.first, triple.second, triple.third)
        }

        fun colorToTriple(color:Int): Triple<Int, Int, Int>{
            return Triple(color.red, color.green, color.blue)
        }

        fun closestColor(pixel: Triple<Int, Int, Int>) : Int{
            var minIndex = 0
            var minDist = dist(pixel, lego_colors[0])
            var d: Int
            var color: Triple<Int, Int, Int>
            for(k in 1 until lego_colors.size){
                color = lego_colors[k]
                d = dist(pixel, color)
                if(d < minDist){
                    minIndex = k; minDist = d
                }
                usedColor[minIndex] = true
            }
            return tripleToColor(lego_colors[minIndex])
        }

        fun transform(bitmap: Bitmap) : Bitmap{

            val pixelsArray = IntArray(bitmap.width * bitmap.height)

            bitmap.getPixels(pixelsArray, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)


            for (y in pixelsArray.indices) {
                pixelsArray[y] = closestColor(colorToTriple(pixelsArray[y]))
            }
            var res = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            res.setPixels(pixelsArray, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            return res
        }

        fun saturate(bitmap:Bitmap, saturationFactor: Float) :Bitmap{

            val pixelsArray = IntArray(bitmap.width * bitmap.height)
            bitmap.getPixels(pixelsArray, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)

            for (k in pixelsArray.indices) {
                var color = pixelsArray[k]
                var hsl = floatArrayOf(0F,0F,0F)
                colorToHSL(color, hsl)
                hsl[1] *= saturationFactor
                pixelsArray[k] = HSLToColor(hsl)
            }
            var b: Bitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true)
            b.setPixels(pixelsArray, 0, bitmap.width, 0, 0, bitmap.width, bitmap.height)
            return b
        }

        fun toPixels(bitmap: Bitmap, height: Int): Bitmap{
            val width = floorDiv(height * bitmap.width, bitmap.height)
            return Bitmap.createScaledBitmap(bitmap, width, height, true)
        }

        fun legofyIt(bitmap:Bitmap, height:Int, saturation:Float): Bitmap{
            return transform(saturate(toPixels(bitmap, height), saturation))
        }

        val imageStream = contentResolver.openInputStream(selectedImageURI)
        val bitmap = BitmapFactory.decodeStream(imageStream)

        val path = this.filesDir.absolutePath
        Log.d(TAG, path)
        val newBitmap = legofyIt(bitmap, 80, 4f)

        val tf = File(path,imageFile.nameWithoutExtension + ".png")
        tf.createNewFile()
        newBitmap.compress(Bitmap.CompressFormat.PNG, 80, BufferedOutputStream(FileOutputStream(tf)))

        Log.d(TAG, tf.path)
        //val myBitmap = BitmapFactory.decodeFile(tf.path)
        binding.imageView.setImageBitmap(newBitmap)

        //todo:Log.d(TAG, "${myBitmap.width}x${myBitmap.height}")

        val dataFile = File(path, imageFile.nameWithoutExtension + ".txt")

        //saveBitmap(bitmap, dataFile)
    }

    private fun saveBitmap(bitmap: Bitmap, dataFile: File){
        var r: Int
        var g: Int
        var b: Int
        var tmp = ""
        for(x in 0 until bitmap.width){
            for(y in 0 until bitmap.height){
                tmp = ""
                val argb = bitmap.getPixel(x, y)
                r = Color.red(argb)
                g = Color.green(argb)
                b = Color.blue(argb)
                if(y!=0){
                    tmp = "|"
                }
                dataFile.appendText("$tmp$r,$g,$b")
            }
            if(x != bitmap.width-1){
                dataFile.appendText("\n")
            }
        }
    }

    private fun getRealPathFromURI(contentURI: Uri): String? {
        val result: String?
        val cursor: Cursor? = contentResolver.query(contentURI, null, null, null, null)
        if (cursor == null) { // Source is Dropbox or other similar local file path
            result = contentURI.path
        } else {
            cursor.moveToFirst()
            val idx: Int = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
            result = cursor.getString(idx)
            cursor.close()
        }
        return result
    }

    private fun loadFiles(){
        fileList.clear()
        val path = this.filesDir.absolutePath
        val file = File(path).list()
        file?.forEach {
            if(File(path, it).isFile && !it.contains(".png")) {
                val fileContent: List<String> = File(path, it).readLines()
                val header = fileContent[0]
                header.replace("\n", "")
                val split = header.split(",")
                /*Log.d(TAG,it + " " + split.size.toString())

            Log.d(TAG,"Found $header : $it, ${split[0]}, ${split[1]}")
            */
                fileList.add(FileClass(it, split[0]))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume")
        loadFiles()
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }


    private fun openFile(filePath: String){
        /*Toast.makeText(this, getString(R.string.open_file_toast, name), Toast.LENGTH_SHORT)
            .show()*/
        val intent = Intent(this, TilesActivity::class.java)
        intent.putExtra("filePath", filePath)
        Log.d(TAG, filePath)
        startActivity(intent)
    }

    private fun onClick(position: Int) {
        openFile(fileList[position].name)
    }

}