package com.alf.legoimagetransform

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.alf.legoimagetransform.databinding.ActivityTilesBinding
import com.chaquo.python.Python
import com.chaquo.python.android.AndroidPlatform
import java.io.File

private const val TAG = "TilesActivityTAG"
class TilesActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTilesBinding
    private lateinit var filePath: String
    private lateinit var fileName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTilesBinding.inflate(layoutInflater)
        setContentView(binding.root)


        filePath = intent.getStringExtra("filePath").toString()
        fileName = File(filePath).nameWithoutExtension
        val isNewFile = intent.getBooleanExtra("isNew", true)

        supportActionBar?.title = getString(R.string.app_name)
        supportActionBar?.subtitle = filePath

        binding.saveTest.setOnClickListener {
            runPython()
            readFile()
        }

        setupFile(isNewFile)
    }

    private fun setupFile(isNewFile: Boolean) {
        val path = this.filesDir.absolutePath
        if (isNewFile) {
            File(path, fileName)
        } else {
            val fileContent: List<String> = File(path, fileName).readLines()
            for (k in 1 until fileContent.size) {
                val line = fileContent[k]
                Log.d(TAG, "Reading from file thisisatest.txt : $line")
                if (line != "") {
                    val parts = line.split(",")
                }
            }
        }
        binding.recyclerView.adapter?.notifyDataSetChanged()
    }

    private fun saveFile() {
        val path = this.filesDir
        val file = File(path, fileName)
        file.delete()
        file.appendText("40x40")

        Toast.makeText(this, "Fichier $fileName enregistré !", Toast.LENGTH_SHORT)
            .show()
    }

    private fun runPython(){
        if (! Python.isStarted()) {
            Python.start(AndroidPlatform(this))
        }
        val py = Python.getInstance()
        val module = py.getModule("legofy")

        val savePath = this.filesDir.absolutePath
        //File(filePath).copyTo(File(path, fileName))
        Log.d(TAG, filePath)

        module.callAttr("legofy", filePath, savePath)
    }

    private fun readFile(){
        val path = this.filesDir.absolutePath
        val fileContent: List<String> = File(path, fileName).readLines()
        for (element in fileContent) {
            Log.d(TAG, "Reading : $element")
        }
    }
}