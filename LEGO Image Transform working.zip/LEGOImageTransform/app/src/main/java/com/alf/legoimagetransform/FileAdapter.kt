package com.alf.legoimagetransform

import kotlinx.coroutines.NonCancellable.cancel
import java.nio.file.Files.delete
import android.app.AlertDialog
import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import java.io.File

private const val TAG = "FileAdapterTag"
class FileAdapter(private val context: Context,
                  private val recyclerView: RecyclerView,
                  private val dataset: MutableList<FileClass>,
                  private val onClick: (Int)->Unit):
    RecyclerView.Adapter<FileAdapter.ItemViewHolder>() {

    class ItemViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val fileName: TextView = view.findViewById(R.id.file_name)
        val lastEdit: TextView = view.findViewById(R.id.last_edit)
        val format: TextView = view.findViewById(R.id.format)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.file_layout, parent, false)

        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.fileName.text = dataset[position].name
        /*holder.lastEdit.text = dataset[position].lastEdit*/
        holder.format.text = dataset[position].format.toString()
        holder.itemView.setOnClickListener { onClick(position) }
        holder.itemView.setOnLongClickListener { onLongClick(position) }
    }

    override fun getItemCount(): Int {
        return dataset.size
    }

    private fun onLongClick(position: Int) : Boolean {
        val path = context.filesDir
        val file = File(path, dataset[position].name)

        val alertDialogBuilder = AlertDialog.Builder(context)
        alertDialogBuilder.setTitle("Suppression du fichier")
        alertDialogBuilder.setMessage("Voulez-vous vraiment supprimer le fichier ${dataset[position].name}")
        alertDialogBuilder.setPositiveButton("Supprimer") { _: DialogInterface, _: Int ->
            file.delete()
            Toast.makeText(context, "Fichier $[position].name} supprimé", Toast.LENGTH_SHORT).show()
            dataset.removeAt(position)
            recyclerView.adapter?.notifyDataSetChanged()
        }
        alertDialogBuilder.setNegativeButton("Annuler") { _: DialogInterface, _: Int -> }
        alertDialogBuilder.create().show()
        return true
    }

}