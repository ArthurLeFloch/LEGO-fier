package com.alf.legoimagetransform

class FileClass(_name: String, _format: String) {
    var name = _name
    var format = _format
}